class Estimateservice {
  async Estimateadd(req, res, next) {
    console.log(req.body);

    try {
      const {
        CompanyCode, VOUDATE, Narration, User,
        TotalMetalValue, TotalStoneValue, TotalMakingCharge,
        ExciseDuty, Tax, NetAmount, CustomerName, Address, Phn, data
      } = req.body;

      const len = data.length;

      const tcode = "EST";
      const lastsrl = await AreaMasters.findOne({
        attributes: ["LASTSERIAL"],
        where: { TRANCODE: tcode },
      });

      const srl = lastsrl.dataValues.LASTSERIAL + 1;
      const VOUNO = `${tcode}${srl}`;

      await EstimateMaster.create({
        VOUNUM: VOUNO,
        TRANCODE: tcode,
        VOUDATE: VOUDATE,
        NAME: CustomerName,
        ADDRESS1: Address,
        MOBILENO: Phn,
        GOLDVALUE: TotalMetalValue,
        STONEVALUE: TotalStoneValue,
        MAKINGCHARGE: TotalMakingCharge,
        STAXAMT: Tax,
        BILLAMOUNT: NetAmount,
      });

      // Process EstimateDetails
      const estimateDetailPromises = data.map(async (item) => {
        await EstimateDetails.create({
          VOUSRL: item.id,
          TRANCODE: tcode,
          VOUNUM: VOUNO,
          voudate: VOUDATE,
          PURITY: item.Purity,
          MANUALID: item.ManualId,
          IDNUM: item.ItemId,
          ITEM: item.Item,
          PCS: item.Pcs,
          GROSS_WT: item.GrossWt,
          NETT_WT: item.NETT_WT,
          GOLD_RATE: item.Rate,
          GOLD_VALUE: item.MetalValue,
          MAK_RATE: item.MkgRate,
          MAK_TYPE: item.MkgType,
          MAKING: item.MkgCharge,
          STONE_VALUE: item.StoneValue,
          TOTAL: item.TotalAmount,
          HMCHARGE: item.HMCharge
        });

        // Process ESTIMATESTONES
        const stoneDetailPromises = item.StoneDetails.map(async (stone) => {
          await ESTIMATESTONES.create({
            VOUSRL: stone.id,
            STONE_SRL: stone.Stone_ID,
            TRANCODE: tcode,
            VOUNUM: VOUNO,
            voudate: VOUDATE,
            STONE_CODE: stone.StoneCode,
            STONE_SUB: stone.SubCode,
            DESCRIPTION: stone.StoneName,
            IDNUM: item.ItemId,
            PCS: stone.Pcs,
            WEIGHT: stone.StoneWt,
            RATE: stone.Rate,
            RATE_TYPE: stone.RateType,
            AMOUNT: stone.StoneAmount
          });
        });

        await Promise.all(stoneDetailPromises);
      });

      await Promise.all(estimateDetailPromises);

      // Send a successful response
      return res.status(200).json({
        success: true,
        message: "Estimate added successfully"
      });

    } catch (error) {
      console.error("Error in Estimateadd service:", error);

      // Send an error response
      if (!res.headersSent) {
        return res.status(500).json({
          errMsg: true,
          response: "An error occurred while adding the estimate",
          error: error.message,
        });
      }
    }
  }
}

module.exports = new Estimateservice();
