const LoginService = require("./login.Services.js");
const UserRegService = require("./User.Reg.Services.js");
const DocuploadService = require("./Docupload.Services.js");
const ShowDocService=require("./ShowReport.Services.js");
const Estimateservice=require("./Estimate.service.js");
const Dataservice=require("./Data.Services.js")

module.exports = {
    LoginService,
    UserRegService,
    DocuploadService,
    ShowDocService,
    Estimateservice,
    Dataservice
}