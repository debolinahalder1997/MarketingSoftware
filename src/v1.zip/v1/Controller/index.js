const AuthController = require("./Auth.Controller");
const DocumnetController = require("./Documnet.Controller");

module.exports = {
  AuthController,
  DocumnetController
};