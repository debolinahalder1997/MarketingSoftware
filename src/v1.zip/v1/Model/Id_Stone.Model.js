const { sq } = require("../../DataBase/ormdb");
const { v4: uuidv4 } = require("uuid");
uuidv4();
const { sequelize, DataTypes, UUID, UUIDV4 } = require("sequelize");
const IdStoneMaster = sq.define("id_stone_master", {
  IDNUM: {
    type: DataTypes.BIGINT,
    primaryKey: true,
    autoIncrement: true,
  },
  IDSRL: {
    type: DataTypes.BIGINT,
    references: {
      model: "serial_infos",
      key: "SRL",
    },
  },
  TRANCODE: { type: DataTypes.STRING },
  VOUNUM: {
    type: DataTypes.STRING,
  },
  VOUSRL: { type: DataTypes.BIGINT },
  STONE_CODE: { type: DataTypes.STRING },
  STONE_SUB: { type: DataTypes.STRING },
  STONE_PCS: { type: DataTypes.BIGINT },
  STONE_WEIGHT: { type: DataTypes.DOUBLE(10, 3), defaultValue: 0.0 },
  RATE: { type: DataTypes.DOUBLE(10, 2), defaultValue: 0.0 },
  AMOUNT: { type: DataTypes.DOUBLE(10, 2), defaultValue: 0.0 },
  PACKETID: { type: DataTypes.BIGINT },
  IS_SOLD: {type: DataTypes.TINYINT },
  VOUDATE: { type: DataTypes.DATEONLY },
  transfer: {type: DataTypes.TINYINT},
  CUSTOMER: {
    type: DataTypes.BIGINT,
    references: {
      model: "customer_masters",
      key: "CUSTNO",
    },
  },
  NOT_PRINT: {type: DataTypes.TINYINT},
  RATE_TYPE: { type: DataTypes.STRING },
  TRFR: {type: DataTypes.TINYINT},
  COSTAMOUNT: { type: DataTypes.DOUBLE(10, 2), defaultValue: 0.0 },
  DETAIL: { type: DataTypes.STRING },
  SDETAIL: { type: DataTypes.STRING },
  Stag: { type: DataTypes.STRING },
  COLOUR: { type: DataTypes.STRING },
  CLARITY: { type: DataTypes.STRING },
  rcode: { type: DataTypes.STRING },
  pur_rate: { type: DataTypes.DOUBLE(10, 2), defaultValue: 0.0 },
  COSTRATE: { type: DataTypes.DOUBLE(10, 2), defaultValue: 0.0 },
  Stname: { type: DataTypes.STRING },
});
sq.sync().then(() => {
  console.log("Table created successfully!");
});
module.exports = { IdStoneMaster };
