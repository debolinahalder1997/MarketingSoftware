const { sq } = require("../../DataBase/ormdb");
const { v4: uuidv4 } = require("uuid");
uuidv4();
const { sequelize, DataTypes, UUID, UUIDV4 } = require("sequelize");
const EstimateDetails = sq.define("estimate_detail", {
  id:{type:DataTypes.BIGINT,primaryKey:true,autoIncrement:true},
  VOUSRL: { type: DataTypes.BIGINT, allowNull: false },
  TRANCODE: { type: DataTypes.STRING ,allowNull:true},
  VOUNUM: {
    type: DataTypes.STRING,
    references: {
      model: "estimate_masters",
      key: "VOUNUM",
    },
  },
  voudate:{
      type:DataTypes.DATEONLY
  },

  PURITY: {
    type: DataTypes.BIGINT,
    references: {
      model: "purity_masters",
      key: "PURITY",
    },
  },
  GRADE: {
    type: DataTypes.BIGINT,
    references: {
      model: "grade_masters",
      key: "ID_GRADE",
    },
  },
  ITEM: {
    type: DataTypes.STRING,
    references: {
      model: "main_item_masters",
      key: "ITEMCODE",
    },
  },
  IDNUM:{type:DataTypes.STRING},
  PCS: { type: DataTypes.BIGINT, defaultValue: 0 },
  GROSS_WT: { type: DataTypes.DOUBLE(10, 3), defaultValue: 0.0 },
  STONE_WT: { type: DataTypes.DOUBLE(10, 3), defaultValue: 0.0 },
  NETT_WT: { type: DataTypes.DOUBLE(10, 3), defaultValue: 0.0 },
  GOLD_RATE: { type: DataTypes.DOUBLE(10, 2), defaultValue: 0.0 },
  GOLD_VALUE: { type: DataTypes.DOUBLE(10, 2), defaultValue: 0.0 },
  MAK_RATE: { type: DataTypes.DOUBLE(10, 2), defaultValue: 0.0 },
  MAK_TYPE: { type: DataTypes.DOUBLE(10, 2), defaultValue: 0.0 },
  MAKING: { type: DataTypes.DOUBLE(10, 2), defaultValue: 0.0 },
  STONE_VALUE: { type: DataTypes.DOUBLE(10, 2), defaultValue: 0.0 },
  TOTAL: { type: DataTypes.DOUBLE(10, 2), defaultValue: 0.0 },
  NARRATION: { type: DataTypes.STRING, allowNull: true },
  OTHER:{type: DataTypes.DOUBLE(10, 2), defaultValue: 0.0},
  DETAIL:{type:DataTypes.STRING},
  P_ITEM:{type:DataTypes.STRING},
  CompanyCode: {
    type: DataTypes.STRING,
    allowNull: false,
    references: {
      model: "companymasters",
      key: "CompanyCode",
    },
  },
  OTHERORDER:{
    type:DataTypes.STRING
  },
  RMS_ORDER:{
    type:DataTypes.TINYINT
  },
  TRAN_STATUS:{
    type:DataTypes.STRING
  },
  Act:{
    type:DataTypes.TINYINT
  },
  ICR:{
    type:DataTypes.STRING
  },
  OMtalVal:{
    type: DataTypes.DOUBLE(10, 2), defaultValue: 0.0
  },
  Rdu_Charg:{type: DataTypes.DOUBLE(10, 2), defaultValue: 0.0},
  CfValue:{type: DataTypes.DOUBLE(10, 2), defaultValue: 0.0},
  BillNo:{type:DataTypes.STRING},
  MANUALID:{type:DataTypes.STRING},
  HMCHARGE: { type: DataTypes.DOUBLE(10, 2), defaultValue: 0.0 },
});
sq.sync().then(() => {
  console.log("Table created successfully!");
});
module.exports = { EstimateDetails };
