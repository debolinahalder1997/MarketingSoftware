const { sq } = require("../../DataBase/ormdb");
const { v4: uuidv4 } = require("uuid");
uuidv4();
const { sequelize, DataTypes, UUID, UUIDV4 } = require("sequelize");
const SerialInfo = sq.define("serial_info", {
  SRL: { type: DataTypes.BIGINT, autoIncrement: true, primaryKey: true },
  TRANCODE: { type: DataTypes.STRING, allowNull: true },
  LASTSERIAL: { type: DataTypes.BIGINT },
  NARATION: { type: DataTypes.STRING },
  PRINTVOUCHER: { type: DataTypes.STRING },
  // AUTO: {},
  // MACHINEIP: {},
  // VOUNOTPRINT: {},
  // MONVOUGEN: {},
  // TRANINDEX: {},
  // TSAVE: {},
  // Batch_Print: {},
  // GstDisable: {},
  // PasswordActive: {},
  // Tally: {},
  PRINT_STATUS: { type: DataTypes.STRING },
});
sq.sync().then(() => {
  console.log("Table created successfully!");
});
module.exports = { SerialInfo };
