const { sq } = require("../../DataBase/ormdb");
const { v4: uuidv4 } = require("uuid");
uuidv4();
const { sequelize, DataTypes, UUID, UUIDV4 } = require("sequelize");
const ESTIMATESTONES = sq.define("ESTIMATESTONE", {
  id:{type:DataTypes.BIGINT,primaryKey:true,autoIncrement:true},  
  VOUSRL: { type: DataTypes.BIGINT,  allowNull: false },
  STONE_SRL: { type: DataTypes.BIGINT,allowNull: false},
  VOUNUM: {
    type: DataTypes.STRING, 
    references: {
      model: "estimate_masters",
      key: "VOUNUM",
    },
  },
  voudate:{
      type:DataTypes.DATEONLY
  },

  STONE_CODE: {
    type: DataTypes.STRING,
  },
  STONE_SUB: {
    type: DataTypes.STRING,
  },
  DESCRIPTION: {
    type: DataTypes.STRING,
  },
  PCS: { type: DataTypes.BIGINT, defaultValue: 0 },
  WEIGHT: { type: DataTypes.DOUBLE(10, 3), defaultValue: 0.0 },
  CUSTOMER_PCS:{type:DataTypes.DOUBLE(10, 3), defaultValue: 0.0},
  CUSTOMER_WEIGHT:{type:DataTypes.DOUBLE(10, 3), defaultValue: 0.0},
  RATE:{type:DataTypes.DOUBLE(10, 3), defaultValue: 0.0},
  AMOUNT:{type:DataTypes.DOUBLE(10, 3), defaultValue: 0.0},
  TRANCODE:{type:DataTypes.STRING},
  STAXPER:{type:DataTypes.DOUBLE(10, 3), defaultValue: 0.0},
  STAXAMT2:{type:DataTypes.DOUBLE(10, 3), defaultValue: 0.0},
  TRAN_STATUS:{type:DataTypes.STRING},
  CUSTOMER:{type:DataTypes.STRING},
  NOT_PRINT:{type:DataTypes.INTEGER},
  RATE_TYPE:{type:DataTypes.TINYINT},
  idnum:{type:DataTypes.STRING},
  TRFR:{type:DataTypes.TINYINT},
  ICR:{type:DataTypes.STRING},
  CompanyCode: {
    type: DataTypes.STRING,
    allowNull: false,
    references: {
      model: "companymasters",
      key: "CompanyCode",
    }
  },

});
sq.sync().then(() => {
  console.log("Table created successfully!");
});
module.exports = { ESTIMATESTONES };
