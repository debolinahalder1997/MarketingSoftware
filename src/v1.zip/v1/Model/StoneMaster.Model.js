const { sq } = require("../../DataBase/ormdb");
const { v4: uuidv4 } = require("uuid");
const { sequelize, DataTypes } = require("sequelize");

const StoneMaster = sq.define("stone_masters", {
  Stone_ID: {
    type: DataTypes.BIGINT,
    autoIncrement: true,
    primaryKey: true, // Make sure to set a primary key
    allowNull: false,
  },
  STONE_SUB: {
    type: DataTypes.STRING(10),
    allowNull: true,
  },
  STONE_CODE: {
    type: DataTypes.STRING(10),
    allowNull: false,
  },
  STONE_NAME: { 
    type: DataTypes.STRING, 
    allowNull: false 
  },
  UNIT: { 
    type: DataTypes.BIGINT, 
    allowNull: false 
  },
  STONE_SALE: { 
    type: DataTypes.BIGINT, 
    allowNull: false 
  },
  STONE_PURC: { 
    type: DataTypes.BIGINT, 
    allowNull: false 
  },
  OPPCS: { 
    type: DataTypes.DOUBLE(10, 3), 
    allowNull: true 
  },
  OPWT: { 
    type: DataTypes.DOUBLE(10, 3), 
    allowNull: true 
  },
  STONE_SALE_2: { 
    type: DataTypes.BIGINT, 
    allowNull: false 
  },
  METAL: {
    type: DataTypes.DOUBLE(10, 3),
    allowNull: true,
  },
  STONE_OLD_PURC: {
    type: DataTypes.BIGINT,
    allowNull: false,
  },
  OpStudWt: {
    type: DataTypes.BIGINT,
    allowNull: false,
  },
  STONE_NAME1: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  CompanyCode: {
    type: DataTypes.STRING,
    allowNull: false,
    references: {
      model: "companymasters",
      key: "CompanyCode",
    },
  },
});
sq.sync().then(() => {
  console.log("Table created successfully!");
});
module.exports = { StoneMaster };
