const { sq } = require("../../DataBase/ormdb");
const { DataTypes } = require("sequelize");

// Define the CustomerMaster model
const CustomerMaster = sq.define("customer_masters", {
  CUSTNO: {
    type: DataTypes.BIGINT,
    autoIncrement: true,
    primaryKey: true,
    allowNull: false,
  },
  NAME: { type: DataTypes.STRING, allowNull: false },
  PHONE: { type: DataTypes.BIGINT, allowNull: true },
  ADDRESS1: { type: DataTypes.STRING, allowNull: true },
  ADDRESS2: { type: DataTypes.STRING, allowNull: true },
  ADDRESS3: { type: DataTypes.STRING, allowNull: true },
  GL_CODE: {
    type: DataTypes.BIGINT,
    references: {
      model: "account_masters", // Ensure this model name matches exactly
      key: "GL_CODE",
    },
  },
  CompanyCode: {
    type: DataTypes.STRING,
    allowNull: false,
    references: {
      model: "companymasters",
      key: "CompanyCode",
    },
  },
});

// Sync the model with the database
sq.sync()
  .then(() => {
    console.log("CustomerMaster table created successfully!");
  })
  .catch((err) => {
    console.error("Error creating CustomerMaster table:", err);
  });

module.exports = { CustomerMaster };
