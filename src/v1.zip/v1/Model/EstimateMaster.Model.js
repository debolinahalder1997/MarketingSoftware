const { sq } = require("../../DataBase/ormdb");
const { v4: uuidv4 } = require("uuid");
uuidv4();
const { sequelize, DataTypes, UUID, UUIDV4 } = require("sequelize");
const EstimateMaster = sq.define("estimate_masters", {
  VOUNUM: {
    type: DataTypes.STRING,
    primaryKey: true,
    allowNull: false,
  },
  TRANCODE: {
    type: DataTypes.STRING,
    allowNull: true,
    defaultValue: null,
  },
  VOUDATE: { type: DataTypes.DATEONLY, allowNull: true },
  ORDERNO: {
    type: DataTypes.BIGINT,
    allowNull: true,
    defaultValue: 0,
  },
  ORDERNO1: { type: DataTypes.BIGINT, allowNull: true, defaultValue: 0 },
  ORDERNO2: { type: DataTypes.BIGINT, allowNull: true, defaultValue: 0 },
  ORDERNO3: { type: DataTypes.BIGINT, allowNull: true, defaultValue: 0 },
  ORDERNO4: { type: DataTypes.BIGINT, allowNull: true, defaultValue: 0 },
  PURITY: {
    type: DataTypes.BIGINT,
    references: {
      model: "purity_masters",
      key: "PURITY",
    },
  },
  GRADE: {
    type: DataTypes.BIGINT,
    references: {
      model: "grade_masters",
      key: "ID_GRADE",
    },
  },
  NAME: {
    type: DataTypes.STRING,
    defaultValue: null,
  },
  ADDRESS1: { type: DataTypes.STRING, allowNull: true, defaultValue: null },
  ADDRESS2: { type: DataTypes.STRING, allowNull: true, defaultValue: null },
  ADDRESS3: { type: DataTypes.STRING, allowNull: true, defaultValue: null },
  TOT_GROSS: { type: DataTypes.DOUBLE(10, 3), defaultValue: 0.0 },
  TOT_NETT: { type: DataTypes.DOUBLE(10, 3), defaultValue: 0.0 },
  TOT_ADJ: { type: DataTypes.DOUBLE(10, 3), defaultValue: 0.0 },
  GOLDVALUE: { type: DataTypes.DOUBLE(10, 2), defaultValue: 0.0 },
  STONEVALUE: { type: DataTypes.DOUBLE(10, 2), defaultValue: 0.0 },
  CASHVALUE: { type: DataTypes.DOUBLE(10, 2), defaultValue: 0.0 },
  OTHERCHARGE: { type: DataTypes.DOUBLE(10, 2), defaultValue: 0.0 },
  MAKINGCHARGE: { type: DataTypes.DOUBLE(10, 2), defaultValue: 0.0 },
  STAXPER: { type: DataTypes.DOUBLE(10, 2), defaultValue: 0.0 },
  STAXAMT: { type: DataTypes.DOUBLE(10, 2), defaultValue: 0.0 },
  SURPER: {type: DataTypes.DOUBLE(10, 2), defaultValue: 0.0},
  SURAMT: {type: DataTypes.DOUBLE(10, 2), defaultValue: 0.0},
  DISCOUNT: { type: DataTypes.DOUBLE(10, 2), defaultValue: 0.0 },
  ADJUSTED_AMOUNT: { type: DataTypes.DOUBLE(10, 2), defaultValue: 0.0 },
  ADDPER: { type: DataTypes.DOUBLE(10, 2), defaultValue: 0.0 },
  ADDSURC: { type: DataTypes.DOUBLE(10, 2), defaultValue: 0.0 },
  IFRET: { type: DataTypes.DOUBLE(10, 2), defaultValue: 0.0 },
  GROSSAMT: { type: DataTypes.DOUBLE(10, 2), defaultValue: 0.0 },
  ADDDIS: {type: DataTypes.DOUBLE(10, 2), defaultValue: 0.0},
  TOT_SOLD: { type: DataTypes.DOUBLE(10, 2), defaultValue: 0.0 },
  GOLD_RATE: { type: DataTypes.DOUBLE(10, 2), defaultValue: 0.0 },
  BILLAMOUNT: { type: DataTypes.DOUBLE(10, 2), defaultValue: 0.0 },
  GOLDRV: { type: DataTypes.DOUBLE(10, 2), defaultValue: 0.0},
  CASHRV: { type: DataTypes.DOUBLE(10, 2), defaultValue: 0.0},
  SALESMAN_CODE: {
    type: DataTypes.STRING,
    references: {
      model: "salesman_masters",
      key: "CODE",
    },
  },
  STAXPER2: { type: DataTypes.DOUBLE(10, 2), defaultValue: 0.0 },
  STAXAMT2: { type: DataTypes.DOUBLE(10, 2), defaultValue: 0.0 },
  STAXOTHPER: { type: DataTypes.DOUBLE(10, 2), defaultValue: 0.0 },
  STAXOTHAMT: { type: DataTypes.DOUBLE(10, 2), defaultValue: 0.0 },
  GOLDTAX_PER: { type: DataTypes.DOUBLE(10, 2), defaultValue: 0.0 },
  GOLDTAX_AMT: { type: DataTypes.DOUBLE(10, 2), defaultValue: 0.0 },
  CUST_NAME: { type: DataTypes.STRING, allowNull: true, defaultValue: null },
  REFUND_AMOUNT: { type: DataTypes.DOUBLE(10, 2), defaultValue: 0.0 },
  REFUND_RVNUM: { type: DataTypes.STRING },
  REFUND_GL: {
    type: DataTypes.BIGINT,
    references: {
      model: "account_masters",
      key: "GL_CODE",
    },
  },
  NARATION: { type: DataTypes.STRING, allowNull: true, defaultValue: null },
  MISCCHARGE: { type: DataTypes.DOUBLE(10, 2), defaultValue: 0.0 },
  ACT: { type: DataTypes.DOUBLE(10, 2), defaultValue: 0.0},
  TRAN_STATUS: { type: DataTypes.DOUBLE(10, 2), defaultValue: 0.0},
  PHONE: { type: DataTypes.STRING, allowNull: true, defaultValue: null },
  CANCEL: {type: DataTypes.TINYINT },
  TENDERAMT: { type: DataTypes.DOUBLE(10, 2), defaultValue: 0.0 },
  LOCID: {
    type: DataTypes.BIGINT,
    references: {
      model: "location_masters",
      key: "LOCID",
    },
  },
  ISCHK: {type: DataTypes.TINYINT },
  ROUND: { type: DataTypes.DOUBLE(10, 2), defaultValue: 0.0 },
  NARRATION: { type: DataTypes.STRING, allowNull: true },
  CustBAmt: { type: DataTypes.DOUBLE(10, 2), defaultValue: 0.0 },
  TIMESTR: {type: DataTypes.STRING },
  MOBILENO: { type: DataTypes.STRING, defaultValue: null },
  ExcisePer: { type: DataTypes.DOUBLE(10, 2), defaultValue: 0.0 },
  ExciseAmt: { type: DataTypes.DOUBLE(10, 2), defaultValue: 0.0 },
  CompanyCode: {
    type: DataTypes.STRING,
    allowNull: false,
    references: {
      model: "companymasters",
      key: "CompanyCode",
    },
  },
});
sq.sync().then(() => {
  console.log("Table created successfully!");
});
module.exports = { EstimateMaster };
